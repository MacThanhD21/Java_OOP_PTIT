public class NhanVien {
    private String id, name;

    public NhanVien(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }
    public String getName() {
        return this.name;
    }

    public String getPosition() {
        String res = this.id.substring(0, 2);
        return res;
    }

    public String getSoHieu() {
        return this.id.substring(4);
    }

    public String getBacLuong() {
        return this.id.substring(2, 4);
    }

    @Override
    public String toString() {
        return this.name + " " + this.getPosition() + " " + this.getSoHieu() + " " + this.getBacLuong();
    } 
}
