
import java.util.*;

class Time {
    private String h, m, s;


    public Time(String h, String m, String s) {
        this.h = h;
        this.m = m;
        this.s = s;
    }

    public String getH() {
        return this.h;
    }

    public String getM() {
        return this.m;
    }

    public String getS() {
        return this.s;
    }

    @Override
    public String toString() {
        return this.h + " " + this.m + " " + this.s;
    }
}

class SortIncrease implements Comparator<Time>{

    @Override
    public int compare(Time o1, Time o2) {
        int res1 = Integer.parseInt(o1.getH() + o1.getM() + o1.getS()); 
        int res2 = Integer.parseInt(o2.getH() + o2.getM() + o2.getS()); 

        if(res1 < res2) return -1;
        else return 1;
    }
}

public class J05003 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        ArrayList<Time> arr = new ArrayList<>();
        for(int i = 0; i < n; i++) {
            sc.nextLine();
            arr.add(new Time(sc.next(), sc.next(), sc.next()));
        }

        Collections.sort(arr, new SortIncrease());

        for(Time x : arr) {
            System.out.println(x);
        }
    }
}
